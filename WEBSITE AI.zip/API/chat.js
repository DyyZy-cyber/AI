let conversations = {}; // Simpan history tiap user (sederhana, in-memory)

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  const { message, userId } = req.body;

  if (!message || !userId) {
    return res.status(400).json({ error: "Message and userId are required" });
  }

  // Inisialisasi history kalau user baru
  if (!conversations[userId]) {
    conversations[userId] = [
      { role: "system", content: "Kamu adalah AI asisten yang cerdas, ramah, santai, kadang bercanda tapi tetap membantu." }
    ];
  }

  // Tambahin pesan user ke history
  conversations[userId].push({ role: "user", content: message });

  try {
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`,
      },
      body: JSON.stringify({
        model: "gpt-3.5-turbo",
        messages: conversations[userId],
        max_tokens: 500,
      }),
    });

    const data = await response.json();

    if (data.error) {
      return res.status(400).json({ error: data.error.message });
    }

    const reply = data.choices[0].message.content;

    // Simpan jawaban ke history
    conversations[userId].push({ role: "assistant", content: reply });

    return res.status(200).json({ reply });

  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
}